#include <Windows.h>
#include <iostream>
#include <string>
#include <sstream>
#include <vector>
#include <process.h>
#include <fstream>

using namespace std;

vector<string> split(const string& s) {
    vector<string> res;
    stringstream ss(s);
    string w;
    while (ss >> w) res.push_back(w);
    return res;
}

void execCmd(const string& cmd) {
    char buf[4096];
    string full = cmd + " 2>&1";
    FILE* pipe = _popen(full.c_str(), "r");
    if (!pipe) { cout << "Failed to execute command" << endl; return; }
    while (fgets(buf, sizeof(buf), pipe)) cout << buf;
    _pclose(pipe);
}

void showHelp() {
    cout << "\n==================== Command List ====================\n";
    cout << "help             Show all commands\n";
    cout << "wq               Exit terminal\n";
    cout << "js               Calculator\n";
    cout << "cmd go           Enter pure CMD mode\n";
    cout << "cmd exit         Exit CMD mode\n";
    cout << "admin [app]      Run as administrator\n";
    cout << "let [password]   Unlock let commands\n";
    cout << "let cd [drive]   Backup system (unlocked required)\n";
    cout << "let wq [src] [dst] Restore system (unlocked required)\n";
    cout << "let [app]        Run as SYSTEM (unlocked required)\n";
    cout << "=======================================================\n";
}

void runNormal(const string& cmd) {
    ShellExecuteA(NULL, NULL, cmd.c_str(), NULL, NULL, SW_SHOWNORMAL);
}

void runAdmin(const string& cmd) {
    cout << "[Admin] " << cmd << endl;
    ShellExecuteA(NULL, "runas", cmd.c_str(), NULL, NULL, SW_SHOWNORMAL);
}

void runSystem(const string& cmd) {
    cout << "[SYSTEM] " << cmd << endl;
    string s = "psexec -s \"" + cmd + "\"";
    system(s.c_str());
}

void doBackup(const string& dr) {
    cout << "[let] Backup to " << dr << " (simulated)" << endl;
}

void doRestore(const string& a, const string& b) {
    cout << "[let wq] Restore " << a << " -> " << b << endl;
}

void calc() { system("calc"); }

string getPwdFile() {
    char path[MAX_PATH];
    GetModuleFileNameA(NULL, path, MAX_PATH);
    string s(path);
    return s.substr(0, s.find_last_of("\\") + 1) + "let_pwd.dat";
}

string loadPwd() {
    ifstream f(getPwdFile(), ios::binary);
    string pwd;
    if (f) getline(f, pwd);
    return pwd;
}

void savePwd(const string& pwd) {
    ofstream f(getPwdFile(), ios::binary);
    f << pwd << endl;
}

string forceSetPwd() {
    cout << "=======================================================\n";
    cout << "          YOU MUST SET LET PASSWORD TO CONTINUE\n";
    cout << "                NO PASSWORD = NO USE\n";
    cout << "=======================================================\n";
    string p1, p2;
    while (true) {
        cout << "\nSet let password: ";
        cin >> p1;
        cout << "Confirm password: ";
        cin >> p2;
        if (p1 == p2 && !p1.empty()) break;
        cout << "Mismatch or empty! Try again.\n";
    }
    savePwd(p1);
    cin.ignore();
    cout << "\nPassword set! Terminal ready.\n";
    return p1;
}

int main() {
    SetConsoleTitleA("Let System Terminal");
    string letPwd = loadPwd();
    if (letPwd.empty()) letPwd = forceSetPwd();

    bool unlocked = false;
    bool cmdMode = false;
    string line;

    while (true) {
        if (!cmdMode) cout << "\nTerminal> ";
        else cout << "\nCMD> ";

        getline(cin, line);
        vector<string> args = split(line);
        if (args.empty()) continue;

        if (cmdMode) {
            if (line == "cmd exit") { cmdMode = false; cout << "Exited CMD mode.\n"; }
            else execCmd(line);
            continue;
        }

        string c0 = args[0];
        if (c0 == "help") { showHelp(); continue; }
        if (c0 == "wq") { cout << "Exited.\n"; break; }
        if (c0 == "js") { calc(); continue; }
        if (c0 == "cmd" && args.size() >= 2 && args[1] == "go") { cmdMode = true; continue; }

        if (c0 == "let") {
            if (!unlocked) {
                if (args.size() >= 2 && args[1] == letPwd) {
                    unlocked = true;
                    cout << "[Success] Let mode unlocked!\n";
                } else {
                    cout << "[Error] Please use: let [password] to unlock\n";
                }
                continue;
            }

            if (args.size() >= 2 && args[1] == "cd" && args.size() >= 3) {
                doBackup(args[2]);
                continue;
            }
            if (args.size() >= 2 && args[1] == "wq" && args.size() >= 4) {
                doRestore(args[2], args[3]);
                continue;
            }

            string app;
            for (size_t i = 1; i < args.size(); i++) {
                if (i > 1) app += " ";
                app += args[i];
            }
            runSystem(app);
            continue;
        }

        if (c0 == "admin") {
            string app;
            for (size_t i = 1; i < args.size(); i++) {
                if (i > 1) app += " ";
                app += args[i];
            }
            runAdmin(app);
            continue;
        }

        runNormal(line);
    }
    return 0;
}
